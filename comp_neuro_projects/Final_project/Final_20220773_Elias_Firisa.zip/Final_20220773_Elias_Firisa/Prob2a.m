n = 10; k = 3;
count = nchoosek(n - k + 1, k);
fprintf('Number of valid patterns = %d\n', count);
